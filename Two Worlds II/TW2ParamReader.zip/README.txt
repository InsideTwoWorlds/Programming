LICENSE AGREEMENT:
Software provided "AS IS", without warranty of any kind, use it on your own risk. 
